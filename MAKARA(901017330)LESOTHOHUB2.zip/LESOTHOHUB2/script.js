// Search Functionality for Home Page
function searchProducts() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const products = document.querySelectorAll('.product');
    products.forEach(product => {
        const productName = product.querySelector('.product-name').textContent.toLowerCase();
        if (productName.includes(searchInput)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// Form Validation for Contact Page
function validateForm() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    if (!name || !email || !message) {
        alert('All fields are required.');
        return false;
    }
    return true;
}
let currentIndex = 0;

function moveSlide(direction) {
  const slides = document.querySelectorAll('.carousel-images img');
  currentIndex = (currentIndex + direction + slides.length) % slides.length;
  const offset = -currentIndex * 100;
  document.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`; 
}

// Optional: Auto slide every 5 seconds
setInterval(() => moveSlide(0.5), 3000);

// Toggle Tips Visibility
function toggleTips() {
    const tipsSection = document.getElementById('tips');
    if (tipsSection.style.display === 'none' || tipsSection.style.display === '') {
        tipsSection.style.display = 'block';
    } else {
        tipsSection.style.display = 'none';
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('searchButton');
    if (searchButton) {
        searchButton.addEventListener('click', searchProducts);
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            if (!validateForm()) {
                e.preventDefault(); // Prevent form submission if validation fails
            }
        });
    }

    const toggleButton = document.getElementById('toggleTipsButton');
    if (toggleButton) {
        toggleButton.addEventListener('click', toggleTips);
    }
});